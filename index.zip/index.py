# This attempts to be (more or less) the simplest possible hello world Alexa skill...
from __future__ import print_function
import requests
import subprocess
import json
import ast
# We'll start with a couple of globals...
CardTitlePrefix = "Greeting"

"""
An application programming interface key (API key) 
is a code passed in by computer programs to validate 
that the user can used the api
"""
headers = {
    'api_key': '101b189f9e6642d4bd3e5b80edf31951',
    }


# --------------- Helpers that build all of the responses ----------------------
def build_speechlet_response(title, output, reprompt_text, should_end_session):
    """
    Build a speechlet JSON representation of the title, output text, 
    reprompt text & end of session
    """
    return {
        'outputSpeech': {
            'type': 'PlainText',
            'text': output
        },
        'card': {
            'type': 'Simple',
            'title': CardTitlePrefix + " - " + title,
            'content': output
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        'shouldEndSession': should_end_session
    }
	
def build_response(session_attributes, speechlet_response):
    """
    Build the full response JSON from the speechlet response
    """
    return {
        'version': '1.0',
        'sessionAttributes': session_attributes,
        'response': speechlet_response
    }
# --------------- Functions that control the skill's behavior ------------------
def get_welcome_response():
    session_attributes = {}
    card_title = "Hello"
    speech_output = "Welcome to the Washington Metropolitan Skill... How may I help you?"
    # If the user either does not reply to the welcome message or says something
    # that is not understood, they will be prompted again with this text.
    reprompt_text = "I'm sorry - I didn't understand. What would you like?..."
    should_end_session = False
    return build_response(session_attributes, build_speechlet_response(card_title, speech_output, reprompt_text, should_end_session))
	
def handle_session_end_request():
    card_title = "Session Ended"
    speech_output = "Have a nice day! "
    # Setting this to true ends the session and exits the skill.
    should_end_session = True
    return build_response({}, build_speechlet_response(card_title, speech_output, None, should_end_session))
		
def incidents(intent_request, session):
    card_title = "Overall Incidents"
    URL = "https://api.wmata.com/Incidents.svc/json/Incidents"
    r = requests.get(url = URL, headers=headers)
    data = r.json()
    
    count = len(data['Incidents']) - 1
    incident=""

    for x in range(count):
        incident=incident +" "+ data['Incidents'][x]['Description']
    
	incident=fix_wording(incident)
    
    return build_response({}, build_speechlet_response(card_title, incident, "Overall Incidents", True))
	
def incidentsByRail(intent_request, session):
    card_title = "Overall Incidents"
    URL = "https://api.wmata.com/Incidents.svc/json/Incidents"
    r = requests.get(url = URL, headers=headers)
    data = r.json()
    
    count = len(data['Incidents']) - 1
    incident=""
    rail_color=intent_request['intent']['slots']['rail_color']['value']

    rail_color=convert_text(rail_color)
	
    for x in range(count):
        if rail_color in data['Incidents'][x]['LinesAffected']:
            incident=incident +" "+ data['Incidents'][x]['Description']

    if not incident:
        incident="There are no issues to report"
    
    incident=fix_wording(incident)
    
    return build_response({}, build_speechlet_response(card_title, incident, "Incidents by Rail Color", True))

	
def timingByStationAndRail(intent_request, session):
    card_title = "Overall Incidents"
    URL = "https://api.wmata.com/StationPrediction.svc/json/GetPrediction/All"
    r = requests.get(url = URL, headers=headers)
    data = r.json()
    count = len(data['Trains']) - 1
    arivial=""
    rail_color=intent_request['intent']['slots']['rail_color']['value']
    color=convert_text(rail_color)
    station=intent_request['intent']['slots']['station_name']['resolutions']['resolutionsPerAuthority'][0]['values'][0]['value']['name']
	
    for x in range(count):
        if color.lower() in data['Trains'][x]['Line'].lower() and station.lower() in data['Trains'][x]['LocationName'].lower():
            arivial=str(data['Trains'][x]['Min'])
            if arivial in "ARR":
                arivial="Train is arriving."
                break
            if arivial in "BRD":
                arivial="Train is currently boarding"
                break
            if arivial:
                arivial="The train will be ariving in " + arivial + " minutes"
                break

    if not arivial:
        arivial="There are no " + rail_color + " line trains ariving at " + station
    return build_response({}, build_speechlet_response(card_title, arivial, "Arival Times", True))


"""
Since the WMATA API uses abbriviations we need to fix the wording
"""	
def convert_text(word):
    word=word.replace("red","RD")
    word=word.replace("yellow","Y/L")
    word=word.replace("green", "GR")
    word=word.replace("orange", "OR")
    word=word.replace("silver", "SV")
    word=word.replace("blue", "BL")
    return word
	
def fix_wording(sentence):
    sentence=sentence.replace("/", "and");
    sentence=sentence.replace("GR", "green");
    sentence=sentence.replace("YL", "yellow");
    sentence=sentence.replace("RD", "red");
    sentence=sentence.replace("btwn", "between");
    sentence=sentence.replace("add'l", "additional");
    return sentence
		
# --------------- Events ------------------
def on_session_started(session_started_request, session):
    """ Called when the session starts """
    print("on_session_started requestId=" + session_started_request['requestId']
          + ", sessionId=" + session['sessionId'])
		  
		  
def on_launch(launch_request, session):
    """ Called when the user launches the skill without specifying what they want """
    print("on_launch requestId=" + launch_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # Dispatch to your skill's launch
    return get_welcome_response()
	
	
def on_intent(intent_request, session):
    """ Called when the user specifies an intent for this skill """
    print("on_intent requestId=" + intent_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    intent = intent_request['intent']
    intent_name = intent_request['intent']['name']
    # Dispatch to your skill's intent handlers
    if intent_name == "incidents":
        return incidents(intent_request, session)
    elif intent_name == "incidentsByRail":
        return incidentsByRail(intent_request, session)
    elif intent_name == "timingByStationAndRail":
        return timingByStationAndRail(intent_request, session)
    elif intent_name == "AMAZON.HelpIntent":
        return get_welcome_response()
    elif intent_name == "AMAZON.CancelIntent" or intent_name == "AMAZON.StopIntent":
        return handle_session_end_request()
    else:
        raise ValueError("Invalid intent")
		
		
def on_session_ended(session_ended_request, session):
    """ Called when the user ends the session. Is not called when the skill returns should_end_session=true """
    print("on_session_ended requestId=" + session_ended_request['requestId'] +
          ", sessionId=" + session['sessionId'])
		  
		  
# --------------- Main handler ------------------
"""
This is the starting point for the Lambda
based on the request type from the alexa skill
the appropriate function will be triggered
"""
def handler(event, context):
    print("event.session.application.applicationId=" +
          event['session']['application']['applicationId'])
    if event['session']['new']:
        on_session_started({'requestId': event['request']['requestId']},
                           event['session'])
    if event['request']['type'] == "LaunchRequest":
        return on_launch(event['request'], event['session'])
    elif event['request']['type'] == "IntentRequest":
        return on_intent(event['request'], event['session'])
    elif event['request']['type'] == "SessionEndedRequest":
        return on_session_ended(event['request'], event['session'])
		
		